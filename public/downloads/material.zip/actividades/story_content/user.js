function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5gj5behgVgF":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

